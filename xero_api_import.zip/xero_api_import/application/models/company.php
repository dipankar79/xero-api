<?php
Class Company extends CI_Model
{
 function login()
 {
   $this -> db -> select('id', 'name');
   $this -> db -> from('companys');

     
 
   $query = $this -> db -> get();
 
   if($query -> num_rows() == 1)
   {
     return $query->result();
   }
   else
   {
     return false;
   }
 }
}
?>