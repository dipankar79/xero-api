<?php

class Csv_model extends CI_Model {
    
    function __construct() {
        parent::__construct();
        $this->load->database(); 
        
    }

    function companys_name()
      {     
        $query = $this->db->get('companys');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }   
      }

      function get_csvfiles()
      {     
        $query = $this->db->get('csv_payment_file');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }   
      }
    
    function get_payments() {     
        $query = $this->db->get('all_payments');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }

    function get_icdn_report() {     
        $query = $this->db->get('icdn_report',0,10);

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }

    function get_tenants_all() {     
        $query = $this->db->get('tenants_all');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }

    function get_tenants_with_balance() {     
        $query = $this->db->get('tenants_with_balance');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }
    
    function insert_csv($data) {
        //$this->db->insert('addressbook', $data);
        $this->db->insert('all_payments', $data);
    }

    function insert_csv_icdn_report($data) {       
        $this->db->insert('icdn_report', $data);
    }

    function insert_csv_tenants_all($data) {       
        $this->db->insert('tenants_all', $data);
    }

    function insert_csv_tenants_with_balance($data) {       
        $this->db->insert('tenants_with_balance', $data);
    }
}
/*END OF FILE*/
