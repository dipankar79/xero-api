<?php
Class Company extends CI_Model
{

  public function __construct() {
    $this->load->database(); 
  }
  function companys_name()
  {     
    $query = $this->db->get('companys');
    return $query->result();    
  }

  public function set_data()
    {
      $this->load->helper('url');

      $slug = url_title($this->input->post('title'), 'dash', TRUE);

      $data = array(
          'title' => $this->input->post('title'),
          'slug' => $slug,
          'text' => $this->input->post('text')
      );

      return $this->db->insert('table_news', $data);
    }

    function insert_csv($data) {
        $this->db->insert('addressbook', $data);
    }
}
?>