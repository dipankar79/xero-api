<?php

class Csv extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Csv_model');
        $this->load->helper('url_helper');
        $this->load->library('Csvimport');
    }

    function index() {
        $data['companys']       = $this->Csv_model->companys_name();
        $data['entty']       = $this->Csv_model->get_csvfiles();
        $data['filedata']    = $this->Csv_model->get_payments();
        $data['icdnreport']    = $this->Csv_model->get_icdn_report();
        
        $this->load->view('csvindex', $data);
    }

    function importcsv() {

        //print_r($_POST);
        //exit();
        $data['filedata'] = $this->Csv_model->get_payments();
        $data['error'] = '';    //initialize image upload error array to empty

        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '1000';

        $this->load->library('upload', $config);


        // If upload failed, display error
        if (!$this->upload->do_upload()) {
            $data['error'] = $this->upload->display_errors();

            $this->load->view('csvindex', $data);
        } else {
            $file_data = $this->upload->data();
            $file_path =  './uploads/'.$file_data['file_name'];
            
            if ($this->csvimport->get_array($file_path)) {
                $csv_array = $this->csvimport->get_array($file_path);
                foreach ($csv_array as $row) {
                    /*$insert_data = array(
                        'company_id'=>$_POST['company_id'],
                        'entty_id'=>$_POST['entty_id'],
                        'firstname'=>$row['firstname'],
                        'lastname'=>$row['lastname'],
                        'phone'=>$row['phone'],
                        'email'=>$row['email'],
                    );*/
                    if($_POST['entty_id']=="1") {
                        $insert_data = array(
                            'company_id'=>$_POST['company_id'],
                            'entty_id'=>$_POST['entty_id'],
                            'PaymentRecordID'=>$row['PaymentRecordID'],
                            'PrevID'=>$row['ID'],
                            'PropertyID'=>$row['PropertyID'],
                            'property'=>$row['Property'],
                            'bankstatementdate'=>$row['BankStatementDate'],
                            'recondate'=>$row['ReconDate'],
                            'payorid'=>$row['PayorID'],
                            'payorname'=>$row['PayorName'],
                            'beforesplitamount'=>$row['BeforeSplitAmount'],
                            'paidamount'=>$row['PaidAmount'],
                            'formattedpaidamount'=>$row['FormattedPaidAmount'],
                            'paymenttype'=>$row['PaymentType'],
                            'CurrencyBeforeSplitAmount'=>$row['CurrencyBeforeSplitAmount'],
                            'TransactionFee'=>$row['TransactionFee'],
                            'ServiceFee'=>$row['ServiceFee'],
                            'Status'=>$row['Status'],
                            'AfterSplitAmount'=>$row['AfterSplitAmount'],
                            'AfterSplitAmountVAT'=>$row['AfterSplitAmountVAT'],
                            'CurrencyAfterSplitAmount'=>$row['CurrencyAfterSplitAmount'],
                            'BenType'=>$row['BenType'],
                            'BenID'=>$row['BenID'],
                            'BeneficiaryName'=>$row['BeneficiaryName'],
                            'TransferredDate'=>$row['TransferredDate'],
                            'RemitID'=>$row['RemitID'],
                            'RemitStatus'=>$row['RemitStatus'],
                            'DiffAmount'=>$row['DiffAmount'],
                            'TransferredDateMonth'=>$row['TransferredDateMonth'],
                            'BalanceAmount'=>$row['BalanceAmount'],
                            'AdjustmentAmount'=>$row['AdjustmentAmount'],
                            'AdjustedAmount'=>$row['AdjustedAmount'],
                            'BenDescription'=>$row['BenDescription'],
                            'BenReference'=>$row['BenReference'],
                            'ResponsibleAgent'=>$row['ResponsibleAgent'],
                            'BeneficiaryType'=>$row['BeneficiaryType'],
                            'DepRef'=>$row['DepRef'],
                            'PartOfAmount'=>$row['PartOfAmount'],
                        );
                        $this->Csv_model->insert_csv($insert_data);
                    }
                    if($_POST['entty_id']=="2") {

                        $insert_data = array(
                            'company_id'=>$_POST['company_id'],
                            'entty_id'=>$_POST['entty_id'],
                            'PropertyID'=>$row['Property ID'],
                            'Property'=>$row['Property'],
                            'Date'=>$row['Date'],
                            'Type'=>$row['Type'],
                            'InvoiceType'=>$row['Invoice Type'],
                            'TenantID'=>$row['Tenant ID'],
                            'Tenant'=>$row['Tenant'],
                            'Description'=>$row['Description'],
                            'Amount'=>$row['Amount'],
                            'VAT'=>$row['VAT'],
                            'Refno'=>$row['Ref no'],                           
                        );
                        $this->Csv_model->insert_csv_icdn_report($insert_data);

                    }

                    if($_POST['entty_id']=="3") {

                        $insert_data = array(
                            'company_id'=>$_POST['company_id'],
                            'entty_id'=>$_POST['entty_id'],
                            'No'=>$row['No'],
                            'PayorName'=>$row['PayorName'],
                            'PropertyID'=>$row['PropertyID'],
                            'PropertyName'=>$row['PropertyName'],
                            'DepositID'=>$row['DepositID'],
                            'Amount'=>$row['Amount'],
                            'Currency'=>$row['Currency'],
                            'PayDay'=>$row['PayDay'],
                            'AccountType'=>$row['AccountType'],
                            'Balance'=>$row['Balance'],                               
                            'ContractID'=>$row['ContractID'],
                            'EmailAddress'=>$row['EmailAddress'],
                            'Mobile'=>$row['Mobile'],                            
                            'ResponsibleAgent'=>$row['ResponsibleAgent'],
                            'Address1'=>$row['Address1'],
                            'Address2'=>$row['Address2'],
                            'Address3'=>$row['Address3'],                            
                            'City'=>$row['City'],
                            'Province'=>$row['Province'],
                            'PostalCode'=>$row['PostalCode'], 
                            'Country'=>$row['Country'],
                            'Phone'=>$row['Phone'],
                            'Fax'=>$row['Fax'],
                            'PayerStatus'=>$row['PayerStatus'],
                            'StartDate'=>$row['StartDate'],
                            'EndDate'=>$row['EndDate'],
                            'NotifyEmail'=>$row['NotifyEmail'],
                            'NotifySMS'=>$row['NotifySMS'],
                            'DepBalance'=>$row['DepBalance'],
                            'LastInvoice'=>$row['LastInvoice'],
                            'LastPayment'=>$row['LastPayment'],
                            'LastReminder'=>$row['LastReminder'],                                                 
                        );
                        $this->Csv_model->insert_csv_tenants_all($insert_data);

                    }

                    if($_POST['entty_id']=="4") {

                        $insert_data = array(
                            'company_id'=>$_POST['company_id'],
                            'entty_id'=>$_POST['entty_id'],
                            'No'=>$row['No'],
                            'PayorName'=>$row['PayorName'],
                            'PropertyID'=>$row['PropertyID'],
                            'PropertyName'=>$row['PropertyName'],
                            'DepositID'=>$row['DepositID'],
                            'Amount'=>$row['Amount'],
                            'Currency'=>$row['Currency'],
                            'PayDay'=>$row['PayDay'],
                            'AccountType'=>$row['AccountType'],
                            'Balance'=>$row['Balance'],                               
                            'ContractID'=>$row['ContractID'],
                            'EmailAddress'=>$row['EmailAddress'],
                            'Mobile'=>$row['Mobile'],                            
                            'ResponsibleAgent'=>$row['ResponsibleAgent'],
                            'Address1'=>$row['Address1'],
                            'Address2'=>$row['Address2'],
                            'Address3'=>$row['Address3'],                            
                            'City'=>$row['City'],
                            'Province'=>$row['Province'],
                            'PostalCode'=>$row['PostalCode'], 
                            'Country'=>$row['Country'],
                            'Phone'=>$row['Phone'],
                            'Fax'=>$row['Fax'],
                            'PayerStatus'=>$row['PayerStatus'],
                            'StartDate'=>$row['StartDate'],
                            'EndDate'=>$row['EndDate'],
                            'NotifyEmail'=>$row['NotifyEmail'],
                            'NotifySMS'=>$row['NotifySMS'],
                            'DepBalance'=>$row['DepBalance'],
                            'LastInvoice'=>$row['LastInvoice'],
                            'LastPayment'=>$row['LastPayment'],
                            'LastReminder'=>$row['LastReminder'],                                                 
                        );
                        $this->Csv_model->insert_csv_tenants_with_balance($insert_data);

                    }
                }
                $this->session->set_flashdata('success', 'Csv Data Imported Succesfully');
                redirect(base_url().'csv');
                //echo "<pre>"; print_r($insert_data);
            } else 
                $data['error'] = "Error occured";
                $this->load->view('csvindex', $data);
            }
            
        } 

}
/*END OF FILE*/
