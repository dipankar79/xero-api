
			</div>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo site_url("assets/bootstrap/js/bootstrap.js"); ?>"></script>
	</body>
</html>
