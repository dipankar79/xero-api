
   <h1>File Upload</h1>   
   <?php
   foreach($companys as $v){
      $data['id'][] = $v->id;
      $data['name'][] = $v->name;
    }
   ?>
   <?php echo validation_errors(); ?>
  <?php //echo form_open_multipart('dataprocess/fileupload'); ?>
  <?php echo form_open_multipart('dataprocess/upload'); ?>
     <label for="company_name" style="width:200px;">Company Name:</label>
      <select name="comany_name">
        <?php foreach ($data['name'] as $key => $value) { ?>
          <option value="<?php echo $data['id'][$key];?>"><?php echo $value;?></option>
        <?php } ?>        
      </select>
     <br/>
     <label for="entty_name" style="width:200px;">Entity Name:</label>
      <select name="entty_name">
        <?php foreach ($entty as $key => $value) { ?>
          <option value="<?php echo $key;?>"><?php echo $value;?></option>
        <?php } ?>        
      </select>
     <br/>

     <label for="entty_name1" style="width:100px;">Upload File:</label>
     <div style="margin-top:-25px;padding-left:205px;">
     <input type="file" name="file">
     </div>
     <br/>
     <input type="submit" value="Submit"/>
     </form>
  