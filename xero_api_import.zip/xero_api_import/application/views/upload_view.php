<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
   <title>File Upload</title>
 </head>
 <body>
   <h1>File Upload</h1>
   <?php echo validation_errors(); ?>
   <?php
   foreach($companys as $v){
      $data['id'][] = $v->id;
      $data['name'][] = $v->name;
    }
   ?>
   <?php //echo form_open('verifylogin'); ?>
     <label for="company_name">Company Name:</label>
      <select name="comany_name">
        <?php foreach ($data['name'] as $key => $value) { ?>
          <option value="<?php echo $data['id'][$key];?>"><?php echo $value;?></option>
        <?php } ?>        
      </select>
     <br/>
     <label for="entty_name">Entty Name:</label>
      <select name="entty_name">
        <?php foreach ($entty as $key => $value) { ?>
          <option value="<?php echo $key;?>"><?php echo $value;?></option>
        <?php } ?>        
      </select>
     <br/>
     <input type="submit" value="Submit"/>
   </form>
 </body>
</html>