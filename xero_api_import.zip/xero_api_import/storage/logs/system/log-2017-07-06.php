<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-06 13:55:36 --> Severity: Warning --> mysqli::real_connect(): (28000/1045): Access denied for user 'fill-this...'@'localhost' (using password: YES) /home/sologics/public_html/sites/sologicsolutions.in/sub_domains/sandbox/xero_api_import/system/database/drivers/mysqli/mysqli_driver.php 202
ERROR - 2017-07-06 13:55:36 --> Unable to connect to the database
