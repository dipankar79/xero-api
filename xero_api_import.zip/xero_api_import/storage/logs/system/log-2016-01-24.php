<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-24 16:43:17 --> Severity: Notice --> Undefined variable: companys /home/equipsys/public_html/sub_domains/sandbox/xero_api_import/application/views/csvindex.php 52
ERROR - 2016-01-24 16:43:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/equipsys/public_html/sub_domains/sandbox/xero_api_import/application/views/csvindex.php 52
ERROR - 2016-01-24 16:43:17 --> Severity: Notice --> Undefined variable: entty /home/equipsys/public_html/sub_domains/sandbox/xero_api_import/application/views/csvindex.php 60
ERROR - 2016-01-24 16:43:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/equipsys/public_html/sub_domains/sandbox/xero_api_import/application/views/csvindex.php 60
ERROR - 2016-01-24 16:43:17 --> Severity: Notice --> Undefined variable: icdnreport /home/equipsys/public_html/sub_domains/sandbox/xero_api_import/application/views/csvindex.php 111
